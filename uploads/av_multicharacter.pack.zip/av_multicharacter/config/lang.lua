Lang = {
    ['title'] = "Multicharacter",
    ['menu_title'] = "Multicharacter Options",
    ['my_vehicles'] = "Vehicle",
    ['scenes'] = "Scene",
    ['saved'] = "Your settings have been saved correctly.",
}