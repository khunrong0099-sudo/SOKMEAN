Config = Config or {}
Config.CustomSpawn = false -- true if using a custom spawn script, add the event/export in client/editable/spawn.lua > line 100
-- Housing/Apartments config
Config.PSHousing = false -- true if using ps-housing: https://github.com/Project-Sloth/ps-housing
Config.QBCoreApartments = false -- True/False, teleport inside apartment after register a new character (requires qb-apartments/qbox properties)
Config.StartingApartment = false -- true/false, for qbox only, gives a starting apartment to new players