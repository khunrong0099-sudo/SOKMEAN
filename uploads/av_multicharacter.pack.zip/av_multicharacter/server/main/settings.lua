local L0_1, L1_1, L2_1, L3_1
L0_1 = {}
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2
  L0_2 = LoadResourceFile
  L1_2 = "av_multicharacter"
  L2_2 = "json/players.json"
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    if L0_2 then
      L1_2 = json
      L1_2 = L1_2.decode
      L2_2 = L0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        goto lbl_17
      end
    end
    L1_2 = {}
    ::lbl_17::
    L0_1 = L1_2
  end
end
L1_1(L2_1)
L1_1 = RegisterServerEvent
L2_1 = "av_multicharacter:saveSettings"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = source
  L2_2 = GetPlayerIdentifierByType
  L3_2 = L1_2
  L4_2 = Config
  L4_2 = L4_2.Identifier
  L2_2 = L2_2(L3_2, L4_2)
  if A0_2 then
    L3_2 = A0_2.vehicle
    if L3_2 then
      L3_2 = SetVehicle
      L4_2 = L1_2
      L5_2 = A0_2.vehicle
      L3_2(L4_2, L5_2)
      A0_2.vehicle = nil
    end
  end
  L3_2 = L0_1
  L3_2[L2_2] = A0_2
  L3_2 = SaveResourceFile
  L4_2 = "av_multicharacter"
  L5_2 = "json/players.json"
  L6_2 = json
  L6_2 = L6_2.encode
  L7_2 = L0_1
  L6_2 = L6_2(L7_2)
  L7_2 = -1
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2)
  if L3_2 then
    L4_2 = TriggerClientEvent
    L5_2 = "av_multicharacter:notification"
    L6_2 = L1_2
    L7_2 = Lang
    L7_2 = L7_2.title
    L8_2 = Lang
    L8_2 = L8_2.saved
    L9_2 = "success"
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
  else
    L4_2 = warn
    L5_2 = "Seems like your hosting provider is blocking you from overwritting files, this is NOT a script problem"
    L4_2(L5_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = lib
L1_1 = L1_1.callback
L1_1 = L1_1.register
L2_1 = "av_multicharacter:getSettings"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = A0_2
  L2_2 = GetPlayerIdentifierByType
  L3_2 = L1_2
  L4_2 = Config
  L4_2 = L4_2.Identifier
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = L0_1
  if L3_2 then
    L3_2 = L0_1
    L3_2 = L3_2[L2_2]
    if L3_2 then
      goto lbl_16
    end
  end
  L3_2 = {}
  ::lbl_16::
  L4_2 = GetIdentifier
  L5_2 = L1_2
  L4_2 = L4_2(L5_2)
  if L4_2 then
    L5_2 = GetVehicle
    L6_2 = L4_2
    L5_2 = L5_2(L6_2)
    L3_2.vehicle = L5_2
  end
  return L3_2
end
L1_1(L2_1, L3_1)
