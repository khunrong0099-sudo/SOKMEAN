local L0_1, L1_1, L2_1, L3_1
L0_1 = false
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = GetConvar
  L1_2 = "sv_hostname"
  L2_2 = ""
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = string
    L1_2 = L1_2.lower
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L0_2 = L1_2
    L1_2 = string
    L1_2 = L1_2.match
    L2_2 = L0_2
    L3_2 = "dovux"
    L1_2 = L1_2(L2_2, L3_2)
    if L1_2 then
      return
    else
      L1_2 = true
      L0_1 = L1_2
    end
  end
end
L1_1(L2_1)
L1_1 = lib
L1_1 = L1_1.callback
L1_1 = L1_1.register
L2_1 = "av_multicharacter:init"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = L0_1
  if L1_2 then
    L1_2 = A0_2
    L2_2 = SetPlayerRoutingBucket
    L3_2 = L1_2
    L4_2 = math
    L4_2 = L4_2.random
    L5_2 = 1
    L6_2 = 60
    L4_2, L5_2, L6_2 = L4_2(L5_2, L6_2)
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
  L1_2 = L0_1
  return L1_2
end
L1_1(L2_1, L3_1)
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L0_1
  if not L1_2 then
    return
  end
  L1_2 = SetPlayerRoutingBucket
  L2_2 = A0_2
  L3_2 = 0
  L1_2(L2_2, L3_2)
end
Init = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = L0_1
  if not L1_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = string
  L1_2 = L1_2.match
  L2_2 = A0_2
  L3_2 = "(%d+)/(%d+)/(%d+)"
  L1_2, L2_2, L3_2 = L1_2(L2_2, L3_2)
  if L1_2 and L2_2 and L3_2 then
    L4_2 = string
    L4_2 = L4_2.format
    L5_2 = "%s-%s-%s"
    L6_2 = L3_2
    L7_2 = L2_2
    L8_2 = L1_2
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  else
    return A0_2
  end
end
Format = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L0_1
  if not L1_2 then
    return
  end
  L1_2 = TriggerClientEvent
  L2_2 = "av_multicharacter:openEditor"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
Editor = L1_1
