local L0_1, L1_1, L2_1
L0_1 = {}
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2
  L0_2 = LoadResourceFile
  L1_2 = "av_multicharacter"
  L2_2 = "json/vehicles.json"
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    if L0_2 then
      L1_2 = json
      L1_2 = L1_2.decode
      L2_2 = L0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        goto lbl_17
      end
    end
    L1_2 = {}
    ::lbl_17::
    L0_1 = L1_2
  end
end
L1_1(L2_1)
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = L0_1
  L1_2 = L1_2[A0_2]
  if not L1_2 then
    L1_2 = false
  end
  L2_2 = dbug
  L3_2 = "GetVehicle(identifier, plates)"
  L4_2 = A0_2
  L5_2 = L1_2
  L2_2(L3_2, L4_2, L5_2)
  return L1_2
end
GetVehicle = L1_1
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = GetIdentifier
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L3_2 = L0_1
    L3_2[L2_2] = A1_2
    L3_2 = SaveResourceFile
    L4_2 = "av_multicharacter"
    L5_2 = "json/vehicles.json"
    L6_2 = json
    L6_2 = L6_2.encode
    L7_2 = L0_1
    L6_2 = L6_2(L7_2)
    L7_2 = -1
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2)
    if not L3_2 then
      L4_2 = warn
      L5_2 = "Seems like your hosting provider is blocking you from overwritting files, this is NOT a script problem"
      L4_2(L5_2)
    end
  end
end
SetVehicle = L1_1
