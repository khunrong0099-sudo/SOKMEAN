local L0_1, L1_1, L2_1, L3_1
L0_1 = {}
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2
  L0_2 = LoadResourceFile
  L1_2 = "av_multicharacter"
  L2_2 = "json/slots.json"
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    if L0_2 then
      L1_2 = json
      L1_2 = L1_2.decode
      L2_2 = L0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        goto lbl_17
      end
    end
    L1_2 = {}
    ::lbl_17::
    L0_1 = L1_2
  end
end
L1_1(L2_1)
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  if not A0_2 or not A1_2 then
    L3_2 = warn
    L4_2 = "addSlot export missing parameter (source, amount)"
    L5_2 = A0_2
    L6_2 = A1_2
    L3_2(L4_2, L5_2, L6_2)
    L3_2 = false
    return L3_2
  end
  L3_2 = GetPlayerIdentifierByType
  L4_2 = A0_2
  L5_2 = Config
  L5_2 = L5_2.Identifier
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = dbug
  L5_2 = "AddSlot(identifier, amount, temp)"
  L6_2 = L3_2
  L7_2 = A1_2
  L8_2 = A2_2
  L4_2(L5_2, L6_2, L7_2, L8_2)
  if L3_2 then
    L4_2 = GetSlots
    L5_2 = A0_2
    L4_2 = L4_2(L5_2)
    L5_2 = Config
    L5_2 = L5_2.Slots
    if L5_2 then
      L5_2 = Config
      L5_2 = L5_2.Slots
      L5_2 = L5_2.default
      if L5_2 then
        goto lbl_38
      end
    end
    L5_2 = 3
    ::lbl_38::
    L6_2 = L4_2 + L5_2
    L7_2 = dbug
    L8_2 = "currentSlots, maxSlots"
    L9_2 = L6_2
    L10_2 = Config
    L10_2 = L10_2.Slots
    L10_2 = L10_2.max
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = Config
    L7_2 = L7_2.Slots
    L7_2 = L7_2.max
    if L6_2 < L7_2 then
      L7_2 = L6_2 + A1_2
      L8_2 = Config
      L8_2 = L8_2.Slots
      L8_2 = L8_2.max
      if L7_2 <= L8_2 then
        L7_2 = L0_1
        L8_2 = L0_1
        L8_2 = L8_2[L3_2]
        if not L8_2 then
          L8_2 = 0
        end
        L7_2[L3_2] = L8_2
        L7_2 = L0_1
        L8_2 = L7_2[L3_2]
        L8_2 = L8_2 + A1_2
        L7_2[L3_2] = L8_2
        if not A2_2 then
          L7_2 = SaveResourceFile
          L8_2 = "av_multicharacter"
          L9_2 = "json/slots.json"
          L10_2 = json
          L10_2 = L10_2.encode
          L11_2 = L0_1
          L10_2 = L10_2(L11_2)
          L11_2 = -1
          L7_2(L8_2, L9_2, L10_2, L11_2)
        end
    end
    else
      L7_2 = warn
      L8_2 = "Player already own the max slots available (identifier, currentSlots)"
      L9_2 = L3_2
      L10_2 = L6_2
      L7_2(L8_2, L9_2, L10_2)
    end
  else
    L4_2 = warn
    L5_2 = "Identifier not found for player (source, identifier type)"
    L6_2 = A0_2
    L7_2 = Config
    L7_2 = L7_2.Identifier
    L4_2(L5_2, L6_2, L7_2)
  end
  L4_2 = false
  return L4_2
end
AddSlot = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = 0
  L2_2 = GetPlayerIdentifierByType
  L3_2 = A0_2
  L4_2 = Config
  L4_2 = L4_2.Identifier
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = dbug
  L4_2 = "GetSlots(source, identifier)"
  L5_2 = A0_2
  L6_2 = L2_2
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = L0_1
  if L3_2 then
    L3_2 = L0_1
    L3_2 = L3_2[L2_2]
    if L3_2 then
      L3_2 = tonumber
      L4_2 = L0_1
      L4_2 = L4_2[L2_2]
      L3_2 = L3_2(L4_2)
      L1_2 = L3_2
    end
  end
  return L1_2
end
GetSlots = L1_1
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = 0
  L3_2 = GetPlayerIdentifierByType
  L4_2 = A0_2
  L5_2 = Config
  L5_2 = L5_2.Identifier
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = dbug
  L5_2 = "RemoveSlot(source, identifier, amount)"
  L6_2 = A0_2
  L7_2 = L3_2
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = L0_1
  if L4_2 then
    L4_2 = L0_1
    L4_2 = L4_2[L3_2]
    if L4_2 then
      if not A1_2 then
        A1_2 = 1
      end
      L4_2 = L0_1
      L5_2 = L4_2[L3_2]
      L5_2 = L5_2 - A1_2
      L4_2[L3_2] = L5_2
      L4_2 = L0_1
      L4_2 = L4_2[L3_2]
      if L4_2 < 0 then
        L4_2 = L0_1
        L4_2[L3_2] = 0
      end
      L4_2 = L0_1
      L2_2 = L4_2[L3_2]
      L4_2 = SaveResourceFile
      L5_2 = "av_multicharacter"
      L6_2 = "json/slots.json"
      L7_2 = json
      L7_2 = L7_2.encode
      L8_2 = L0_1
      L7_2 = L7_2(L8_2)
      L8_2 = -1
      L4_2(L5_2, L6_2, L7_2, L8_2)
    end
  end
  return L2_2
end
RemoveSlot = L1_1
L1_1 = exports
L2_1 = "AddSlot"
L3_1 = AddSlot
L1_1(L2_1, L3_1)
L1_1 = exports
L2_1 = "GetSlots"
L3_1 = GetSlots
L1_1(L2_1, L3_1)
L1_1 = exports
L2_1 = "RemoveSlot"
L3_1 = RemoveSlot
L1_1(L2_1, L3_1)
