local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
inGizmo = false
L1_1 = RegisterNetEvent
L2_1 = "av_multicharacter:openEditor"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = FreeCam
  L0_2()
  L0_2 = SetNuiFocus
  L1_2 = true
  L2_2 = true
  L0_2(L1_2, L2_2)
  L0_2 = SetEntityAlpha
  L1_2 = cache
  L1_2 = L1_2.ped
  L2_2 = 155
  L3_2 = false
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.action = "editor"
  L1_2.data = true
  L0_2(L1_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "newObject"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L2_2 = false
  L3_2 = A0_2
  if L3_2 then
    L4_2 = GetHashKey
    L5_2 = L3_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      goto lbl_11
    end
  end
  L4_2 = 123
  ::lbl_11::
  if L3_2 then
    L5_2 = IsModelValid
    L6_2 = L3_2
    L5_2 = L5_2(L6_2)
    if L5_2 then
      L5_2 = inGizmo
      if not L5_2 then
        L5_2 = lib
        L5_2 = L5_2.requestModel
        L6_2 = L3_2
        L7_2 = 30000
        L5_2(L6_2, L7_2)
        L5_2 = dbug
        L6_2 = "newObject(model)"
        L7_2 = L3_2
        L5_2(L6_2, L7_2)
        L5_2 = GetCam
        L5_2 = L5_2()
        L6_2 = GetEntityCoords
        L7_2 = cache
        L7_2 = L7_2.ped
        L6_2 = L6_2(L7_2)
        L7_2 = SpawnObject
        L8_2 = L4_2
        L9_2 = L6_2
        L7_2 = L7_2(L8_2, L9_2)
        while true do
          L8_2 = DoesEntityExist
          L9_2 = L7_2
          L8_2 = L8_2(L9_2)
          if L8_2 then
            break
          end
          L8_2 = Wait
          L9_2 = 50
          L8_2(L9_2)
        end
        if L5_2 then
          L8_2 = GetCamMatrix
          L9_2 = L5_2
          L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
          L12_2 = L9_2 * 5
          L12_2 = L11_2 + L12_2
          L13_2 = SetEntityCoords
          L14_2 = L7_2
          L15_2 = L12_2.x
          L16_2 = L12_2.y
          L17_2 = L12_2.z
          L18_2 = true
          L19_2 = false
          L20_2 = false
          L21_2 = false
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
        end
        L8_2 = SetNuiFocus
        L9_2 = false
        L10_2 = false
        L8_2(L9_2, L10_2)
        inGizmo = true
        L8_2 = exports
        L8_2 = L8_2.object_gizmo
        L9_2 = L8_2
        L8_2 = L8_2.useGizmo
        L10_2 = L7_2
        L8_2 = L8_2(L9_2, L10_2)
        L9_2 = lib
        L9_2 = L9_2.string
        L9_2 = L9_2.random
        L10_2 = "........"
        L9_2 = L9_2(L10_2)
        L10_2 = {}
        L11_2 = L8_2.position
        L10_2.position = L11_2
        L11_2 = L8_2.rotation
        L10_2.rootation = L11_2
        L10_2.model = L3_2
        L10_2.identifier = L9_2
        L10_2.handler = L7_2
        L2_2 = L10_2
        L10_2 = L0_1
        L10_2[L9_2] = L2_2
        L10_2 = SetNuiFocus
        L11_2 = true
        L12_2 = true
        L10_2(L11_2, L12_2)
        inGizmo = false
    end
  end
  else
    L5_2 = TriggerEvent
    L6_2 = "av_multicharacter:notification"
    L7_2 = "Editor"
    L8_2 = "Model "
    L9_2 = L3_2
    L10_2 = " doesn't exist in your game (?)"
    L8_2 = L8_2 .. L9_2 .. L10_2
    L9_2 = "error"
    L5_2(L6_2, L7_2, L8_2, L9_2)
  end
  L5_2 = A1_2
  L6_2 = L2_2
  L5_2(L6_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "editObject"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L2_2 = A0_2.identifier
  L3_2 = L0_1
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = L0_1
    L3_2 = L3_2[L2_2]
    L3_2 = L3_2.handler
    if L3_2 then
      goto lbl_12
    end
  end
  L3_2 = false
  ::lbl_12::
  if L3_2 then
    L4_2 = DoesEntityExist
    L5_2 = L3_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      L4_2 = inGizmo
      if not L4_2 then
        L4_2 = SetNuiFocus
        L5_2 = false
        L6_2 = false
        L4_2(L5_2, L6_2)
        L4_2 = SetGameplayEntityHint
        L5_2 = L3_2
        L6_2 = 0.0
        L7_2 = 0.0
        L8_2 = 0.0
        L9_2 = false
        L10_2 = 500
        L11_2 = 500
        L12_2 = 500
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
        inGizmo = true
        L4_2 = exports
        L4_2 = L4_2.object_gizmo
        L5_2 = L4_2
        L4_2 = L4_2.useGizmo
        L6_2 = L3_2
        L4_2 = L4_2(L5_2, L6_2)
        if L4_2 then
          L5_2 = L0_1
          L6_2 = {}
          L7_2 = L4_2.position
          L6_2.position = L7_2
          L7_2 = L4_2.rotation
          L6_2.rootation = L7_2
          L7_2 = A0_2.model
          L6_2.model = L7_2
          L6_2.identifier = L2_2
          L6_2.handler = L3_2
          L5_2[L2_2] = L6_2
          L5_2 = L0_1
          A0_2 = L5_2[L2_2]
        end
        L5_2 = SetNuiFocus
        L6_2 = true
        L7_2 = true
        L5_2(L6_2, L7_2)
        inGizmo = false
      end
    end
  end
  L4_2 = A1_2
  L5_2 = A0_2
  L4_2(L5_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "delObject"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = A0_2 or nil
  if A0_2 then
    L2_2 = A0_2.identifier
  end
  L3_2 = L0_1
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = L0_1
    L3_2 = L3_2[L2_2]
    if L3_2 then
      L3_2 = L0_1
      L3_2 = L3_2[L2_2]
      L3_2 = L3_2.handler
    end
    if L3_2 then
      L4_2 = DoesEntityExist
      L5_2 = L3_2
      L4_2 = L4_2(L5_2)
      if L4_2 then
        L4_2 = SetEntityAsNoLongerNeeded
        L5_2 = L3_2
        L4_2(L5_2)
        L4_2 = DeleteEntity
        L5_2 = L3_2
        L4_2(L5_2)
        L4_2 = L0_1
        L4_2[L2_2] = nil
      end
    end
  end
  L3_2 = A1_2
  L4_2 = "ok"
  L3_2(L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "copy"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L2_2 = A0_2 or nil
  if A0_2 then
    L2_2 = A0_2.identifier
  end
  L3_2 = L0_1
  L3_2 = L3_2[L2_2]
  L4_2 = L3_2.handler
  if L3_2 then
    L5_2 = DoesEntityExist
    L6_2 = L4_2
    L5_2 = L5_2(L6_2)
    if L5_2 then
      L5_2 = L3_2.position
      L6_2 = GetEntityHeading
      L7_2 = L4_2
      L6_2 = L6_2(L7_2)
      L7_2 = lib
      L7_2 = L7_2.setClipboard
      L8_2 = "{ x = "
      L9_2 = Round
      L10_2 = L5_2.x
      L11_2 = 2
      L9_2 = L9_2(L10_2, L11_2)
      L10_2 = ", y = "
      L11_2 = Round
      L12_2 = L5_2.y
      L13_2 = 2
      L11_2 = L11_2(L12_2, L13_2)
      L12_2 = ", z = "
      L13_2 = Round
      L14_2 = L5_2.z
      L15_2 = 2
      L13_2 = L13_2(L14_2, L15_2)
      L14_2 = ", heading = "
      L15_2 = Round
      L16_2 = L6_2
      L17_2 = 2
      L15_2 = L15_2(L16_2, L17_2)
      L16_2 = ", model = \""
      L17_2 = L3_2.model
      L18_2 = "\" },"
      L8_2 = L8_2 .. L9_2 .. L10_2 .. L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2
      L7_2(L8_2)
      L7_2 = TriggerEvent
      L8_2 = "av_multicharacter:notification"
      L9_2 = "Editor"
      L10_2 = "Coords added to clipboard"
      L11_2 = "success"
      L7_2(L8_2, L9_2, L10_2, L11_2)
    end
  end
  L5_2 = A1_2
  L6_2 = "ok"
  L5_2(L6_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "closeEditor"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = WipeAll
  L2_2()
  L2_2 = DestroyFreeCam
  L2_2()
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.action = "editor"
  L3_2.data = false
  L2_2(L3_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = pairs
  L1_2 = L0_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    if L5_2 then
      L6_2 = DoesEntityExist
      L7_2 = L5_2.handler
      L6_2 = L6_2(L7_2)
      if L6_2 then
        L6_2 = SetEntityAsMissionEntity
        L7_2 = L5_2.handler
        L6_2(L7_2)
        L6_2 = DeleteEntity
        L7_2 = L5_2.handler
        L6_2(L7_2)
      end
    end
  end
  L0_2 = ResetEntityAlpha
  L1_2 = cache
  L1_2 = L1_2.ped
  L0_2(L1_2)
  L0_2 = FreezeEntityPosition
  L1_2 = cache
  L1_2 = L1_2.ped
  L2_2 = false
  L0_2(L1_2, L2_2)
  L0_2 = {}
  L0_1 = L0_2
end
WipeAll = L1_1
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L2_2 = IsModelAPed
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L2_2 = CreatePed
    L3_2 = 3
    L4_2 = A0_2
    L5_2 = A1_2.x
    L6_2 = A1_2.y
    L7_2 = A1_2.z
    L8_2 = 0.0
    L9_2 = false
    L10_2 = false
    L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
    L3_2 = SetGameplayPedHint
    L4_2 = L2_2
    L5_2 = 0.0
    L6_2 = 0.0
    L7_2 = 0.0
    L8_2 = false
    L9_2 = 500
    L10_2 = 500
    L11_2 = 500
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
    return L2_2
  else
    L2_2 = CreateObject
    L3_2 = A0_2
    L4_2 = A1_2.x
    L5_2 = A1_2.y
    L6_2 = A1_2.z
    L7_2 = false
    L8_2 = false
    L9_2 = false
    L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L3_2 = SetGameplayEntityHint
    L4_2 = L2_2
    L5_2 = 0.0
    L6_2 = 0.0
    L7_2 = 0.0
    L8_2 = false
    L9_2 = 500
    L10_2 = 500
    L11_2 = 500
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
    return L2_2
  end
end
SpawnObject = L1_1
L1_1 = AddEventHandler
L2_1 = "onResourceStop"
function L3_1(A0_2)
  local L1_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if L1_2 ~= A0_2 then
    return
  end
  L1_2 = WipeAll
  L1_2()
end
L1_1(L2_1, L3_1)
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  if not A1_2 then
    L2_2 = math
    L2_2 = L2_2.floor
    L3_2 = A0_2 + 0.5
    return L2_2(L3_2)
  end
  L2_2 = 10
  L2_2 = L2_2 ^ A1_2
  L3_2 = math
  L3_2 = L3_2.floor
  L4_2 = A0_2 * L2_2
  L4_2 = L4_2 + 0.5
  L3_2 = L3_2(L4_2)
  L3_2 = L3_2 / L2_2
  return L3_2
end
Round = L1_1
L1_1 = Config
L1_1 = L1_1.CoordsCommand
if L1_1 then
  L1_1 = RegisterCommand
  L2_1 = Config
  L2_1 = L2_1.CoordsCommand
  function L3_1(A0_2, A1_2)
    local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
    L2_2 = GetEntityCoords
    L3_2 = cache
    L3_2 = L3_2.ped
    L2_2 = L2_2(L3_2)
    L3_2 = GetEntityHeading
    L4_2 = cache
    L4_2 = L4_2.ped
    L3_2 = L3_2(L4_2)
    L4_2 = lib
    L4_2 = L4_2.setClipboard
    L5_2 = "{ x = "
    L6_2 = Round
    L7_2 = L2_2.x
    L8_2 = 2
    L6_2 = L6_2(L7_2, L8_2)
    L7_2 = ", y = "
    L8_2 = Round
    L9_2 = L2_2.y
    L10_2 = 2
    L8_2 = L8_2(L9_2, L10_2)
    L9_2 = ", z = "
    L10_2 = Round
    L11_2 = L2_2.z
    L12_2 = 2
    L10_2 = L10_2(L11_2, L12_2)
    L11_2 = ", heading = "
    L12_2 = Round
    L13_2 = L3_2
    L14_2 = 2
    L12_2 = L12_2(L13_2, L14_2)
    L13_2 = "},"
    L5_2 = L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2 .. L12_2 .. L13_2
    L4_2(L5_2)
    L4_2 = TriggerEvent
    L5_2 = "av_multicharacter:notification"
    L6_2 = "Editor"
    L7_2 = "Coords added to clipboard"
    L8_2 = "success"
    L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_1 = false
  L1_1(L2_1, L3_1, L4_1)
end
