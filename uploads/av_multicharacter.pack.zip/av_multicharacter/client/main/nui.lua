local L0_1, L1_1, L2_1
L0_1 = RegisterNUICallback
L1_1 = "setSlot"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  if A0_2 then
    L2_2 = tonumber
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      goto lbl_9
    end
  end
  L2_2 = 1
  ::lbl_9::
  L3_2 = HandleSlot
  L4_2 = L2_2
  L3_2(L4_2)
  L3_2 = A1_2
  L4_2 = "ok"
  L3_2(L4_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "play"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = Play
  if A0_2 then
    L3_2 = tonumber
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      goto lbl_10
    end
  end
  L3_2 = 1
  ::lbl_10::
  L2_2(L3_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "delete"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  if A0_2 then
    L2_2 = A0_2.slot
    if L2_2 then
      L2_2 = DeleteCharacter
      L3_2 = A0_2.slot
      L2_2(L3_2)
    end
  end
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "register"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = RegisterCharacter
  L3_2 = A0_2
  L2_2(L3_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
