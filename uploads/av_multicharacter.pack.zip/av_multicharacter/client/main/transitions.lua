local L0_1, L1_1
oldCam = 1
transitionTime = 1500
L0_1 = {}
camList = L0_1
currentSlot = 1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  currentSlot = A0_2
  L1_2 = dbug
  L2_2 = "HandleSlot(oldSlot, currentSlot)"
  L3_2 = oldCam
  L4_2 = currentSlot
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = camList
  L2_2 = currentSlot
  L1_2 = L1_2[L2_2]
  if not L1_2 then
    L1_2 = warn
    L2_2 = "Slot "
    L3_2 = currentSlot
    L4_2 = " doesn't have any ped or camera assigned, this is because of a missing config, report it to your server admin, you can still select this slot to play."
    L2_2 = L2_2 .. L3_2 .. L4_2
    L1_2(L2_2)
    return
  end
  L1_2 = currentSlot
  L2_2 = oldCam
  if L1_2 == L2_2 then
    return
  end
  L1_2 = dbug
  L2_2 = "Transition Cam..."
  L1_2(L2_2)
  L1_2 = SetCamActiveWithInterp
  L2_2 = camList
  L3_2 = currentSlot
  L2_2 = L2_2[L3_2]
  L3_2 = camList
  L4_2 = oldCam
  L3_2 = L3_2[L4_2]
  L4_2 = 1700
  L5_2 = 1
  L6_2 = 1
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L1_2 = currentSlot
  oldCam = L1_2
  L1_2 = Wait
  L2_2 = camTransitionMS
  if not L2_2 then
    L2_2 = 1700
  end
  L1_2(L2_2)
end
HandleSlot = L0_1
