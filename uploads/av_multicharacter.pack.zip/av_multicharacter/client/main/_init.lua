local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = false
L1_1 = {}
L2_1 = {}
L3_1 = {}
cameras = L3_1
L3_1 = RegisterNetEvent
L4_1 = "av_multicharacter:init"
function L5_1()
  local L0_2, L1_2
  L0_2 = L0_1
  if L0_2 then
    return
  end
  L0_2 = DoScreenFadeOut
  L1_2 = 1
  L0_2(L1_2)
  L0_2 = Wait
  L1_2 = 500
  L0_2(L1_2)
  L0_2 = init
  L0_2()
end
L3_1(L4_1, L5_1)
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2
  L0_2 = dbug
  L1_2 = "init()"
  L0_2(L1_2)
  currentSlot = 1
  oldCam = 1
  L0_2 = true
  L0_1 = L0_2
  L0_2 = dbug
  L1_2 = "init check..."
  L0_2(L1_2)
  L0_2 = lib
  L0_2 = L0_2.callback
  L0_2 = L0_2.await
  L1_2 = "av_multicharacter:init"
  L2_2 = false
  L0_2 = L0_2(L1_2, L2_2)
  if not L0_2 then
    L1_2 = warn
    L2_2 = "Seems like we can't continue, bye bye :("
    L1_2(L2_2)
    return
  end
  L1_2 = dbug
  L2_2 = "init check done()"
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "av_multicharacter:getSettings"
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = dbug
  L3_2 = "Player Settings"
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = L1_2
  L6_2 = {}
  L6_2.indent = true
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2 = L4_2(L5_2, L6_2)
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
  if L1_2 then
    L2_2 = L1_2.scene
    if L2_2 then
      goto lbl_49
    end
  end
  L2_2 = Config
  L2_2 = L2_2.DefaultScene
  ::lbl_49::
  L3_2 = Scenes
  if L3_2 then
    L3_2 = Scenes
    L3_2 = L3_2[L2_2]
    if not L3_2 then
      L3_2 = warn
      L4_2 = "Scene ^3"
      L5_2 = L2_2
      L6_2 = "^7 was removed from the scenes folder by the sv admin, using default scene."
      L4_2 = L4_2 .. L5_2 .. L6_2
      L3_2(L4_2)
      L3_2 = Config
      L2_2 = L3_2.DefaultScene
    end
  end
  L3_2 = Scenes
  L3_2 = L3_2[L2_2]
  if not L3_2 then
    L3_2 = warn
    L4_2 = "Scene: ^3"
    L5_2 = L2_2
    L6_2 = "^7 doesn't exist in Config.Scenes, report it to a server admin"
    L4_2 = L4_2 .. L5_2 .. L6_2
    L3_2(L4_2)
  end
  L3_2 = dbug
  L4_2 = "Player scene: "
  L5_2 = L2_2
  L3_2(L4_2, L5_2)
  L3_2 = Scenes
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = Scenes
    L3_2 = L3_2[L2_2]
    L3_2 = L3_2.playerSpawn
    if L3_2 then
      goto lbl_88
    end
  end
  L3_2 = false
  ::lbl_88::
  if not L3_2 then
    L4_2 = warn
    L5_2 = "playerSpawn not defined, report it to your server admin. Scene: ^7"
    L6_2 = L2_2
    L5_2 = L5_2 .. L6_2
    L4_2(L5_2)
  end
  L4_2 = Scenes
  L4_2 = L4_2[L2_2]
  if L4_2 then
    L4_2 = Scenes
    L4_2 = L4_2[L2_2]
    L4_2 = L4_2.playerSpawn
    if L4_2 then
      goto lbl_128
    end
  end
  L4_2 = dbug
  L5_2 = "40"
  L4_2(L5_2)
  L4_2 = pairs
  L5_2 = Scenes
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = Scenes
    L10_2 = L10_2[L8_2]
    if L10_2 then
      L10_2 = Scenes
      L10_2 = L10_2[L8_2]
      L10_2 = L10_2.playerSpawn
      if L10_2 then
        L2_2 = L8_2
        L10_2 = Scenes
        L10_2 = L10_2[L2_2]
        L3_2 = L10_2.playerSpawn
        break
      end
    end
  end
  ::lbl_128::
  if not L3_2 then
    L4_2 = warn
    L5_2 = "There's something wrong with your multicharacter config, please report it to a server admin and send a copy of all the prints you have in this console."
    L4_2(L5_2)
    return
  end
  L4_2 = RequestCollisionAtCoord
  L5_2 = L3_2.x
  L6_2 = L3_2.y
  L7_2 = L3_2.z
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = SetFocusPosAndVel
  L5_2 = L3_2.x
  L6_2 = L3_2.y
  L7_2 = L3_2.z
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = FreezeEntityPosition
  L5_2 = cache
  L5_2 = L5_2.ped
  L6_2 = true
  L4_2(L5_2, L6_2)
  L4_2 = SetEntityCoords
  L5_2 = cache
  L5_2 = L5_2.ped
  L6_2 = L3_2.x
  L7_2 = L3_2.y
  L8_2 = L3_2.z
  L9_2 = true
  L10_2 = false
  L11_2 = false
  L12_2 = true
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  if L3_2 then
    L4_2 = L3_2.z
    if L4_2 < 0.0 then
      L4_2 = RequestCollisionAtCoord
      L5_2 = L3_2.x
      L6_2 = L3_2.y
      L7_2 = L3_2.z
      L4_2(L5_2, L6_2, L7_2)
      L4_2 = SetFocusPosAndVel
      L5_2 = L3_2.x
      L6_2 = L3_2.y
      L7_2 = L3_2.z
      L4_2(L5_2, L6_2, L7_2)
      L4_2 = Wait
      L5_2 = 1000
      L4_2(L5_2)
      L4_2 = SetEntityCoords
      L5_2 = cache
      L5_2 = L5_2.ped
      L6_2 = L3_2.x
      L7_2 = L3_2.y
      L8_2 = L3_2.z
      L9_2 = true
      L10_2 = false
      L11_2 = false
      L12_2 = true
      L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
      L4_2 = FreezeEntityPosition
      L5_2 = cache
      L5_2 = L5_2.ped
      L6_2 = true
      L4_2(L5_2, L6_2)
    end
  end
  L4_2 = SetEntityAlpha
  L5_2 = cache
  L5_2 = L5_2.ped
  L6_2 = 0
  L4_2(L5_2, L6_2)
  L4_2 = Scenes
  L4_2 = L4_2[L2_2]
  if L4_2 then
    L4_2 = Scenes
    L4_2 = L4_2[L2_2]
    L4_2 = L4_2.camTransitionMS
    if L4_2 then
      goto lbl_209
    end
  end
  L4_2 = 1700
  ::lbl_209::
  camTransitionMS = L4_2
  L4_2 = GetInteriorAtCoords
  L5_2 = L3_2.x
  L6_2 = L3_2.y
  L7_2 = L3_2.z
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if L4_2 and L4_2 > 0 then
    L5_2 = dbug
    L6_2 = "Load interior..."
    L5_2(L6_2)
    L5_2 = PinInteriorInMemory
    L6_2 = L4_2
    L5_2(L6_2)
    L5_2 = 0
    while true do
      L6_2 = IsInteriorReady
      L7_2 = L4_2
      L6_2 = L6_2(L7_2)
      if L6_2 then
        break
      end
      L6_2 = dbug
      L7_2 = "Loading interior..."
      L8_2 = L5_2
      L7_2 = L7_2 .. L8_2
      L6_2(L7_2)
      L6_2 = PinInteriorInMemory
      L7_2 = L4_2
      L6_2(L7_2)
      L6_2 = Wait
      L7_2 = 100
      L6_2(L7_2)
      L5_2 = L5_2 + 1
      if L5_2 >= 60 then
        L6_2 = dbug
        L7_2 = "The interior couldn't be loaded (?)"
        L6_2(L7_2)
        break
      end
    end
    if L5_2 < 60 then
      L6_2 = dbug
      L7_2 = "Interior loaded"
      L6_2(L7_2)
    end
    L6_2 = RequestCollisionAtCoord
    L7_2 = L3_2.x
    L8_2 = L3_2.y
    L9_2 = L3_2.z
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = SetFocusPosAndVel
    L7_2 = L3_2.x
    L8_2 = L3_2.y
    L9_2 = L3_2.z
    L6_2(L7_2, L8_2, L9_2)
  else
    L5_2 = dbug
    L6_2 = "Scene is not in an interior, continue..."
    L5_2(L6_2)
  end
  L5_2 = SetEntityCoords
  L6_2 = cache
  L6_2 = L6_2.ped
  L7_2 = L3_2.x
  L8_2 = L3_2.y
  L9_2 = L3_2.z
  L10_2 = true
  L11_2 = false
  L12_2 = false
  L13_2 = true
  L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
  L5_2 = FreezeEntityPosition
  L6_2 = cache
  L6_2 = L6_2.ped
  L7_2 = true
  L5_2(L6_2, L7_2)
  L5_2 = CustomScene
  L6_2 = L2_2
  L5_2(L6_2)
  L5_2 = dbug
  L6_2 = "FetchCharacters()"
  L5_2(L6_2)
  L5_2 = FetchCharacters
  L5_2()
  L5_2 = Scenes
  L5_2 = L5_2[L2_2]
  L5_2 = L5_2.characters
  if L5_2 then
    L5_2 = next
    L6_2 = Scenes
    L6_2 = L6_2[L2_2]
    L6_2 = L6_2.characters
    L5_2 = L5_2(L6_2)
    if L5_2 then
      L5_2 = 1
      L6_2 = Scenes
      L6_2 = L6_2[L2_2]
      L6_2 = L6_2.characters
      L6_2 = #L6_2
      L7_2 = 1
      for L8_2 = L5_2, L6_2, L7_2 do
        L9_2 = Scenes
        L9_2 = L9_2[L2_2]
        L9_2 = L9_2.characters
        L9_2 = L9_2[L8_2]
        L10_2 = L9_2.ped
        L10_2 = L10_2.model
        if L10_2 then
          L10_2 = GetHashKey
          L11_2 = L9_2.ped
          L11_2 = L11_2.model
          L10_2 = L10_2(L11_2)
          if L10_2 then
            goto lbl_332
          end
        end
        L10_2 = Config
        L10_2 = L10_2.DefaultPed
        if not L10_2 then
          L10_2 = 1885233650
        end
        ::lbl_332::
        L11_2 = charactersList
        L11_2 = L11_2[L8_2]
        if L11_2 then
          L11_2 = charactersList
          L11_2 = L11_2[L8_2]
          L11_2 = L11_2.clothes
          if L11_2 then
            L11_2 = charactersList
            L11_2 = L11_2[L8_2]
            L11_2 = L11_2.clothes
            L11_2 = L11_2.model
            if L11_2 then
              L11_2 = tonumber
              L12_2 = charactersList
              L12_2 = L12_2[L8_2]
              L12_2 = L12_2.clothes
              L12_2 = L12_2.model
              L11_2 = L11_2(L12_2)
              L10_2 = L11_2
            end
          end
        end
        if L10_2 then
          L11_2 = IsModelValid
          L12_2 = L10_2
          L11_2 = L11_2(L12_2)
          if L11_2 then
            goto lbl_377
          end
        end
        L11_2 = warn
        L12_2 = "Character model"
        L13_2 = L10_2
        L14_2 = "doesn't seem to be valid, using default."
        L11_2(L12_2, L13_2, L14_2)
        L11_2 = Config
        L11_2 = L11_2.DefaultPed
        L10_2 = L11_2 or L10_2
        if not L11_2 then
          L10_2 = 1885233650
        end
        L11_2 = IsModelValid
        L12_2 = L10_2
        L11_2 = L11_2(L12_2)
        if not L11_2 then
          L10_2 = 1885233650
        end
        ::lbl_377::
        L11_2 = L9_2.ped
        if L11_2 then
          L11_2 = next
          L12_2 = L9_2.ped
          L11_2 = L11_2(L12_2)
          if L11_2 then
            L11_2 = RequestCollisionAtCoord
            L12_2 = L9_2.ped
            L12_2 = L12_2.x
            L13_2 = L9_2.ped
            L13_2 = L13_2.y
            L14_2 = L9_2.ped
            L14_2 = L14_2.z
            L11_2(L12_2, L13_2, L14_2)
            L11_2 = Wait
            L12_2 = 10
            L11_2(L12_2)
            L11_2 = CreatePedSpawn
            L12_2 = L10_2
            L13_2 = L9_2.ped
            L13_2 = L13_2.x
            L14_2 = L9_2.ped
            L14_2 = L14_2.y
            L15_2 = L9_2.ped
            L15_2 = L15_2.z
            L15_2 = L15_2 - 1
            L16_2 = L9_2.ped
            L16_2 = L16_2.heading
            L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
            L12_2 = charactersList
            L12_2 = L12_2[L8_2]
            if L12_2 then
              L12_2 = charactersList
              L12_2 = L12_2[L8_2]
              L12_2 = L12_2.clothes
              if L12_2 then
                L12_2 = SetSkin
                L13_2 = L11_2
                L14_2 = charactersList
                L14_2 = L14_2[L8_2]
                L14_2 = L14_2.clothes
                L14_2 = L14_2.skin
                L12_2(L13_2, L14_2)
            end
            else
              L12_2 = CustomSkin
              L13_2 = L11_2
              L14_2 = L10_2
              L12_2(L13_2, L14_2)
            end
            L12_2 = L9_2.scenario
            if L12_2 then
              L12_2 = TaskStartScenarioInPlace
              L13_2 = L11_2
              L14_2 = L9_2.scenario
              L15_2 = 0
              L16_2 = true
              L12_2(L13_2, L14_2, L15_2, L16_2)
            end
            L12_2 = L9_2.animation
            if L12_2 then
              L12_2 = L9_2.animation
              L12_2 = L12_2.dict
              if L12_2 then
                L12_2 = lib
                L12_2 = L12_2.requestAnimDict
                L13_2 = L9_2.animation
                L13_2 = L13_2.dict
                L14_2 = 25000
                L12_2(L13_2, L14_2)
                L12_2 = TaskPlayAnim
                L13_2 = L11_2
                L14_2 = L9_2.animation
                L14_2 = L14_2.dict
                L15_2 = L9_2.animation
                L15_2 = L15_2.anim
                L16_2 = 2.0
                L17_2 = 2.0
                L18_2 = -1
                L19_2 = 1
                L20_2 = 0
                L21_2 = false
                L22_2 = false
                L23_2 = false
                L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
                L12_2 = RemoveAnimDict
                L13_2 = L9_2.animation
                L13_2 = L13_2.dict
                L12_2(L13_2)
              end
            end
            L12_2 = L1_1
            L12_2 = #L12_2
            L13_2 = L12_2 + 1
            L12_2 = L1_1
            L12_2[L13_2] = L11_2
            L12_2 = L9_2.vehicle
            if L12_2 then
              L12_2 = next
              L13_2 = L9_2.vehicle
              L12_2 = L12_2(L13_2)
              if L12_2 then
                L12_2 = L9_2.vehicle
                L12_2 = L12_2.model
                if L12_2 then
                  L12_2 = GetHashKey
                  L13_2 = L9_2.vehicle
                  L13_2 = L13_2.model
                  L12_2 = L12_2(L13_2)
                  if L12_2 then
                    goto lbl_500
                  end
                end
                L12_2 = Config
                L12_2 = L12_2.DefaultVehicle
                if not L12_2 then
                  L12_2 = -1728685474
                end
                ::lbl_500::
                L13_2 = charactersList
                L13_2 = L13_2[L8_2]
                if L13_2 then
                  L13_2 = charactersList
                  L13_2 = L13_2[L8_2]
                  L13_2 = L13_2.vehicle
                  if L13_2 then
                    L13_2 = tonumber
                    L14_2 = charactersList
                    L14_2 = L14_2[L8_2]
                    L14_2 = L14_2.vehicle
                    L14_2 = L14_2.model
                    L13_2 = L13_2(L14_2)
                    L12_2 = L13_2
                  end
                end
                if L12_2 then
                  L13_2 = IsModelInCdimage
                  L14_2 = L12_2
                  L13_2 = L13_2(L14_2)
                  if L13_2 then
                    L13_2 = Config
                    L13_2 = L13_2.BlacklistedVehicles
                    L13_2 = L13_2[L12_2]
                    if not L13_2 then
                      L13_2 = lib
                      L13_2 = L13_2.requestModel
                      L14_2 = L12_2
                      L15_2 = 30000
                      L13_2(L14_2, L15_2)
                      L13_2 = RequestCollisionAtCoord
                      L14_2 = L9_2.vehicle
                      L14_2 = L14_2.x
                      L15_2 = L9_2.vehicle
                      L15_2 = L15_2.y
                      L16_2 = L9_2.vehicle
                      L16_2 = L16_2.z
                      L13_2(L14_2, L15_2, L16_2)
                      L13_2 = Wait
                      L14_2 = 10
                      L13_2(L14_2)
                      L13_2 = CreateVehicle
                      L14_2 = L12_2
                      L15_2 = L9_2.vehicle
                      L15_2 = L15_2.x
                      L16_2 = L9_2.vehicle
                      L16_2 = L16_2.y
                      L17_2 = L9_2.vehicle
                      L17_2 = L17_2.z
                      L18_2 = L9_2.vehicle
                      L18_2 = L18_2.heading
                      L19_2 = false
                      L20_2 = true
                      L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
                      if L13_2 then
                        L14_2 = GetVehicleClass
                        L15_2 = L13_2
                        L14_2 = L14_2(L15_2)
                        L15_2 = Config
                        L15_2 = L15_2.BlacklistedCategories
                        L16_2 = tostring
                        L17_2 = L14_2
                        L16_2 = L16_2(L17_2)
                        L15_2 = L15_2[L16_2]
                        if not L15_2 then
                          L15_2 = SetVehicleEngineOn
                          L16_2 = L13_2
                          L17_2 = true
                          L18_2 = true
                          L19_2 = true
                          L15_2(L16_2, L17_2, L18_2, L19_2)
                          L15_2 = charactersList
                          L15_2 = L15_2[L8_2]
                          if L15_2 then
                            L15_2 = charactersList
                            L15_2 = L15_2[L8_2]
                            L15_2 = L15_2.vehicle
                            if L15_2 then
                              L15_2 = charactersList
                              L15_2 = L15_2[L8_2]
                              L15_2 = L15_2.vehicle
                              L15_2 = L15_2.mods
                              if L15_2 then
                                L15_2 = ApplyTuning
                                L16_2 = L13_2
                                L17_2 = charactersList
                                L17_2 = L17_2[L8_2]
                                L17_2 = L17_2.vehicle
                                L17_2 = L17_2.mods
                                L15_2(L16_2, L17_2)
                              end
                            end
                          end
                          L15_2 = PlaceObjectOnGroundProperly
                          L16_2 = L13_2
                          L15_2(L16_2)
                          L15_2 = L2_1
                          L15_2 = #L15_2
                          L16_2 = L15_2 + 1
                          L15_2 = L2_1
                          L15_2[L16_2] = L13_2
                        else
                          L15_2 = SetEntityAsMissionEntity
                          L16_2 = L13_2
                          L17_2 = false
                          L18_2 = false
                          L15_2(L16_2, L17_2, L18_2)
                          L15_2 = DeleteVehicle
                          L16_2 = L13_2
                          L15_2(L16_2)
                        end
                      end
                    end
                  end
                end
              end
            end
            L12_2 = dbug
            L13_2 = "Load cams"
            L12_2(L13_2)
            L12_2 = CreateCam
            L13_2 = "DEFAULT_SCRIPTED_CAMERA"
            L14_2 = true
            L12_2 = L12_2(L13_2, L14_2)
            L13_2 = SetCamCoord
            L14_2 = L12_2
            L15_2 = L9_2.camera
            L15_2 = L15_2.x
            L16_2 = L9_2.camera
            L16_2 = L16_2.y
            L17_2 = L9_2.camera
            L17_2 = L17_2.z
            L13_2(L14_2, L15_2, L16_2, L17_2)
            L13_2 = SetCamRot
            L14_2 = L12_2
            L15_2 = L9_2.camera
            L15_2 = L15_2.rotX
            L16_2 = L9_2.camera
            L16_2 = L16_2.rotY
            L17_2 = L9_2.camera
            L17_2 = L17_2.rotZ
            L18_2 = 2
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
            L13_2 = SetCamFov
            L14_2 = L12_2
            L15_2 = L9_2.camera
            L15_2 = L15_2.fov
            L13_2(L14_2, L15_2)
            L13_2 = camList
            L14_2 = camList
            L14_2 = #L14_2
            L14_2 = L14_2 + 1
            L13_2[L14_2] = L12_2
        end
        else
          L11_2 = warn
          L12_2 = "No ped coords provided for slot "
          L13_2 = L8_2
          L14_2 = ", verify your config for "
          L15_2 = L2_2
          L16_2 = " scene."
          L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2
          L11_2(L12_2)
        end
        L11_2 = CustomCharacter
        L12_2 = L2_2
        L13_2 = L1_1
        L13_2 = L13_2[L8_2]
        L14_2 = L2_1
        L14_2 = L14_2[L8_2]
        L15_2 = L8_2
        L11_2(L12_2, L13_2, L14_2, L15_2)
      end
      L5_2 = dbug
      L6_2 = "Scene created"
      L5_2(L6_2)
    end
  end
  L5_2 = dbug
  L6_2 = "All characters, vehicles and cameras loaded"
  L5_2(L6_2)
  L5_2 = Scenes
  L5_2 = L5_2[L2_2]
  L5_2 = L5_2.weather
  if L5_2 then
    L5_2 = dbug
    L6_2 = "Set Weather"
    L5_2(L6_2)
    L5_2 = Weather
    L6_2 = true
    L7_2 = Scenes
    L7_2 = L7_2[L2_2]
    L7_2 = L7_2.weather
    L5_2(L6_2, L7_2)
  end
  L5_2 = GetPlayerSlots
  L5_2 = L5_2()
  L6_2 = GetDeletePermission
  L6_2 = L6_2()
  L7_2 = ShutdownLoadingScreen
  L7_2()
  L7_2 = ShutdownLoadingScreenNui
  L7_2()
  L7_2 = dbug
  L8_2 = "SendNUIMessage.."
  L7_2(L8_2)
  L7_2 = SetNuiFocus
  L8_2 = true
  L9_2 = true
  L7_2(L8_2, L9_2)
  L7_2 = SendNUIMessage
  L8_2 = {}
  L8_2.action = "show"
  L9_2 = {}
  L9_2.state = true
  L10_2 = charactersList
  L9_2.characters = L10_2
  L9_2.slots = L5_2
  L9_2.canDelete = L6_2
  L8_2.data = L9_2
  L7_2(L8_2)
  L7_2 = ResetEntityAlpha
  L8_2 = cache
  L8_2 = L8_2.ped
  L7_2(L8_2)
  L7_2 = SetCamActive
  L8_2 = camList
  L9_2 = currentSlot
  L8_2 = L8_2[L9_2]
  L9_2 = true
  L7_2(L8_2, L9_2)
  L7_2 = RenderScriptCams
  L8_2 = true
  L9_2 = false
  L10_2 = 1
  L11_2 = true
  L12_2 = true
  L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
  L7_2 = DoScreenFadeIn
  L8_2 = 1000
  L7_2(L8_2)
  L7_2 = false
  L0_1 = L7_2
  L7_2 = dbug
  L8_2 = "Done init event"
  L7_2(L8_2)
end
init = L3_1
L3_1 = RegisterNetEvent
L4_1 = "av_multicharacter:wipe"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = dbug
  L1_2 = "av_multicharacter:wipe"
  L0_2(L1_2)
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.action = "show"
  L2_2 = {}
  L2_2.state = false
  L1_2.data = L2_2
  L0_2(L1_2)
  L0_2 = L1_1
  if L0_2 then
    L0_2 = next
    L1_2 = L1_1
    L0_2 = L0_2(L1_2)
    if L0_2 then
      L0_2 = pairs
      L1_2 = L1_1
      L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
      for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
        if L5_2 then
          L6_2 = DoesEntityExist
          L7_2 = L5_2
          L6_2 = L6_2(L7_2)
          if L6_2 then
            L6_2 = dbug
            L7_2 = "ped"
            L8_2 = L5_2
            L9_2 = "destroyed"
            L6_2(L7_2, L8_2, L9_2)
            L6_2 = SetEntityAsMissionEntity
            L7_2 = L5_2
            L8_2 = true
            L9_2 = true
            L6_2(L7_2, L8_2, L9_2)
            L6_2 = DeleteEntity
            L7_2 = L5_2
            L6_2(L7_2)
          end
        end
      end
    end
  end
  L0_2 = L2_1
  if L0_2 then
    L0_2 = next
    L1_2 = L2_1
    L0_2 = L0_2(L1_2)
    if L0_2 then
      L0_2 = pairs
      L1_2 = L2_1
      L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
      for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
        if L5_2 then
          L6_2 = DoesEntityExist
          L7_2 = L5_2
          L6_2 = L6_2(L7_2)
          if L6_2 then
            L6_2 = dbug
            L7_2 = "vehicle"
            L8_2 = L5_2
            L9_2 = "destroyed"
            L6_2(L7_2, L8_2, L9_2)
            L6_2 = SetEntityAsMissionEntity
            L7_2 = L5_2
            L8_2 = false
            L9_2 = false
            L6_2(L7_2, L8_2, L9_2)
            L6_2 = DeleteVehicle
            L7_2 = L5_2
            L6_2(L7_2)
          end
        end
      end
    end
  end
  L0_2 = CustomWipe
  L0_2()
  L0_2 = camList
  if L0_2 then
    L0_2 = camList
    L1_2 = currentSlot
    L0_2 = L0_2[L1_2]
    if L0_2 then
      L0_2 = SetCamActive
      L1_2 = camList
      L2_2 = currentSlot
      L1_2 = L1_2[L2_2]
      L2_2 = false
      L0_2(L1_2, L2_2)
    end
  end
  L0_2 = RenderScriptCams
  L1_2 = false
  L2_2 = false
  L3_2 = 0
  L4_2 = true
  L5_2 = true
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
  L0_2 = camList
  if L0_2 then
    L0_2 = next
    L1_2 = camList
    L0_2 = L0_2(L1_2)
    if L0_2 then
      L0_2 = pairs
      L1_2 = camList
      L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
      for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
        if L5_2 then
          L6_2 = DoesCamExist
          L7_2 = L5_2
          L6_2 = L6_2(L7_2)
          if L6_2 then
            L6_2 = DestroyCam
            L7_2 = L5_2
            L8_2 = true
            L6_2(L7_2, L8_2)
            L6_2 = dbug
            L7_2 = "cam"
            L8_2 = L5_2
            L9_2 = "destroyed"
            L6_2(L7_2, L8_2, L9_2)
          end
        end
      end
    end
  end
  L0_2 = DestroyAllCams
  L1_2 = true
  L0_2(L1_2)
  L0_2 = ClearFocus
  L0_2()
  L0_2 = SetFocusEntity
  L1_2 = PlayerPedId
  L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2 = L1_2()
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L0_2 = {}
  L1_1 = L0_2
  L0_2 = {}
  L2_1 = L0_2
  L0_2 = {}
  camList = L0_2
  L0_2 = dbug
  L1_2 = "av_multicharacter:wipe finished"
  L0_2(L1_2)
end
L3_1(L4_1, L5_1)
function L3_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L5_2 = tonumber
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  A0_2 = L5_2
  L5_2 = IsModelInCdimage
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  if not L5_2 then
    L5_2 = print
    L6_2 = "model"
    L7_2 = A0_2
    L8_2 = "doesn't exist"
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = Config
    A0_2 = L5_2.DefaultPed
  end
  L5_2 = lib
  L5_2 = L5_2.requestModel
  L6_2 = A0_2
  L7_2 = 30000
  L5_2(L6_2, L7_2)
  L5_2 = CreatePed
  L6_2 = 0
  L7_2 = A0_2
  L8_2 = A1_2
  L9_2 = A2_2
  L10_2 = A3_2
  L11_2 = A4_2
  L12_2 = false
  L13_2 = false
  return L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
end
CreatePedSpawn = L3_1
