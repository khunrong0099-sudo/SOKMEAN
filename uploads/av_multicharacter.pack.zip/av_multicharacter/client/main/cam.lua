local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = nil
L1_1 = false
L2_1 = nil
L3_1 = 90.0
L4_1 = 0.0
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = L1_1
  if not L0_2 then
    L0_2 = true
    L1_1 = L0_2
    L0_2 = cache
    L0_2 = L0_2.ped
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_1 = L1_2
    L1_2 = CreateCam
    L2_2 = "DEFAULT_SCRIPTED_CAMERA"
    L3_2 = true
    L1_2 = L1_2(L2_2, L3_2)
    L0_1 = L1_2
    L1_2 = SetCamCoord
    L2_2 = L0_1
    L3_2 = L2_1.x
    L4_2 = L2_1.y
    L5_2 = L2_1.z
    L5_2 = L5_2 + 1.0
    L1_2(L2_2, L3_2, L4_2, L5_2)
    L1_2 = SetCamRot
    L2_2 = L0_1
    L3_2 = 0.0
    L4_2 = 0.0
    L5_2 = 0.0
    L1_2(L2_2, L3_2, L4_2, L5_2)
    L1_2 = SetCamFov
    L2_2 = L0_1
    L3_2 = L3_1
    L1_2(L2_2, L3_2)
    L1_2 = SetCamActive
    L2_2 = L0_1
    L3_2 = true
    L1_2(L2_2, L3_2)
    L1_2 = RenderScriptCams
    L2_2 = true
    L3_2 = false
    L4_2 = 0
    L5_2 = true
    L6_2 = true
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
    L1_2 = DisplayHud
    L2_2 = false
    L1_2(L2_2)
    L1_2 = DisplayRadar
    L2_2 = false
    L1_2(L2_2)
    L1_2 = TriggerEvent
    L2_2 = "es:setMoneyDisplay"
    L3_2 = 0.0
    L1_2(L2_2, L3_2)
    L1_2 = FreezeEntityPosition
    L2_2 = L0_2
    L3_2 = true
    L1_2(L2_2, L3_2)
    L1_2 = CreateThread
    function L2_2()
      local L0_3, L1_3
      L0_3 = Loop
      L0_3()
    end
    L1_2(L2_2)
  else
    L0_2 = false
    L1_1 = L0_2
    L0_2 = DestroyCam
    L1_2 = L0_1
    L2_2 = false
    L0_2(L1_2, L2_2)
    L0_2 = RenderScriptCams
    L1_2 = false
    L2_2 = false
    L3_2 = 0
    L4_2 = true
    L5_2 = true
    L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
    L0_2 = nil
    L0_1 = L0_2
    L0_2 = DisplayHud
    L1_2 = true
    L0_2(L1_2)
    L0_2 = DisplayRadar
    L1_2 = true
    L0_2(L1_2)
    L0_2 = TriggerEvent
    L1_2 = "es:setMoneyDisplay"
    L2_2 = 1.0
    L0_2(L1_2, L2_2)
    L0_2 = FreezeEntityPosition
    L1_2 = cache
    L1_2 = L1_2.ped
    L2_2 = false
    L0_2(L1_2, L2_2)
  end
end
FreeCam = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = GetCamRot
  L2_2 = A0_2
  L3_2 = 2
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = math
  L2_2 = L2_2.sin
  L3_2 = math
  L3_2 = L3_2.rad
  L4_2 = L1_2.z
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = L3_2(L4_2)
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L2_2 = -L2_2
  L3_2 = math
  L3_2 = L3_2.abs
  L4_2 = math
  L4_2 = L4_2.cos
  L5_2 = math
  L5_2 = L5_2.rad
  L6_2 = L1_2.x
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  L4_2, L5_2, L6_2, L7_2, L8_2 = L4_2(L5_2, L6_2, L7_2, L8_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L2_2 = L2_2 * L3_2
  L3_2 = math
  L3_2 = L3_2.cos
  L4_2 = math
  L4_2 = L4_2.rad
  L5_2 = L1_2.z
  L4_2, L5_2, L6_2, L7_2, L8_2 = L4_2(L5_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L4_2 = math
  L4_2 = L4_2.abs
  L5_2 = math
  L5_2 = L5_2.cos
  L6_2 = math
  L6_2 = L6_2.rad
  L7_2 = L1_2.x
  L6_2, L7_2, L8_2 = L6_2(L7_2)
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2, L7_2, L8_2)
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2)
  L3_2 = L3_2 * L4_2
  L4_2 = math
  L4_2 = L4_2.sin
  L5_2 = math
  L5_2 = L5_2.rad
  L6_2 = L1_2.x
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2)
  L5_2 = vector3
  L6_2 = L2_2
  L7_2 = L3_2
  L8_2 = L4_2
  return L5_2(L6_2, L7_2, L8_2)
end
GetCamForwardVector = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = GetCamForwardVector
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = vector3
  L3_2 = L1_2.y
  L3_2 = -L3_2
  L4_2 = L1_2.x
  L5_2 = 0.0
  return L2_2(L3_2, L4_2, L5_2)
end
GetCamRightVector = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 30
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 31
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 140
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 141
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 142
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 24
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 25
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 22
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 23
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 75
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 45
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
end
disablePlayerControls = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2
  while true do
    L0_2 = L1_1
    if not L0_2 then
      break
    end
    L0_2 = disablePlayerControls
    L0_2()
    L0_2 = GetCamCoord
    L1_2 = L0_1
    L0_2 = L0_2(L1_2)
    L1_2 = GetCamRot
    L2_2 = L0_1
    L3_2 = 2
    L1_2 = L1_2(L2_2, L3_2)
    L2_2 = IsControlPressed
    L3_2 = 1
    L4_2 = 32
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L2_2 = GetCamForwardVector
      L3_2 = L0_1
      L2_2 = L2_2(L3_2)
      L2_2 = L2_2 * 0.05
      L0_2 = L0_2 + L2_2
    end
    L2_2 = IsControlPressed
    L3_2 = 1
    L4_2 = 33
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L2_2 = GetCamForwardVector
      L3_2 = L0_1
      L2_2 = L2_2(L3_2)
      L2_2 = L2_2 * 0.05
      L0_2 = L0_2 - L2_2
    end
    L2_2 = IsControlPressed
    L3_2 = 1
    L4_2 = 34
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L2_2 = GetCamRightVector
      L3_2 = L0_1
      L2_2 = L2_2(L3_2)
      L2_2 = L2_2 * 0.05
      L0_2 = L0_2 + L2_2
    end
    L2_2 = IsControlPressed
    L3_2 = 1
    L4_2 = 35
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L2_2 = GetCamRightVector
      L3_2 = L0_1
      L2_2 = L2_2(L3_2)
      L2_2 = L2_2 * 0.05
      L0_2 = L0_2 - L2_2
    end
    L2_2 = IsControlPressed
    L3_2 = 1
    L4_2 = 44
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L2_2 = vector3
      L3_2 = 0.0
      L4_2 = 0.0
      L5_2 = 0.05
      L2_2 = L2_2(L3_2, L4_2, L5_2)
      L0_2 = L0_2 + L2_2
    end
    L2_2 = IsControlPressed
    L3_2 = 1
    L4_2 = 38
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L2_2 = vector3
      L3_2 = 0.0
      L4_2 = 0.0
      L5_2 = 0.05
      L2_2 = L2_2(L3_2, L4_2, L5_2)
      L0_2 = L0_2 - L2_2
    end
    L2_2 = SetCamCoord
    L3_2 = L0_1
    L4_2 = L0_2
    L2_2(L3_2, L4_2)
    L2_2 = GetControlNormal
    L3_2 = 0
    L4_2 = 1
    L2_2 = L2_2(L3_2, L4_2)
    L2_2 = L2_2 * 8.0
    L3_2 = GetControlNormal
    L4_2 = 0
    L5_2 = 2
    L3_2 = L3_2(L4_2, L5_2)
    L3_2 = L3_2 * 8.0
    L4_2 = IsControlPressed
    L5_2 = 1
    L6_2 = 174
    L4_2 = L4_2(L5_2, L6_2)
    if L4_2 then
      L4_2 = L4_1
      L4_2 = L4_2 - 0.5
      L4_1 = L4_2
    end
    L4_2 = IsControlPressed
    L5_2 = 1
    L6_2 = 175
    L4_2 = L4_2(L5_2, L6_2)
    if L4_2 then
      L4_2 = L4_1
      L4_2 = L4_2 + 0.5
      L4_1 = L4_2
    end
    L4_2 = vector3
    L5_2 = L1_2.x
    L5_2 = L5_2 - L3_2
    L6_2 = L1_2.y
    L7_2 = L1_2.z
    L7_2 = L7_2 - L2_2
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L1_2 = L4_2
    L4_2 = SetCamRot
    L5_2 = L0_1
    L6_2 = L1_2.x
    L7_2 = L4_1
    L8_2 = L1_2.z
    L9_2 = 2
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
    L4_2 = IsControlPressed
    L5_2 = 1
    L6_2 = 172
    L4_2 = L4_2(L5_2, L6_2)
    if L4_2 then
      L4_2 = math
      L4_2 = L4_2.max
      L5_2 = 30.0
      L6_2 = L3_1
      L6_2 = L6_2 - 0.5
      L4_2 = L4_2(L5_2, L6_2)
      L3_1 = L4_2
      L4_2 = SetCamFov
      L5_2 = L0_1
      L6_2 = L3_1
      L4_2(L5_2, L6_2)
    end
    L4_2 = IsControlPressed
    L5_2 = 1
    L6_2 = 173
    L4_2 = L4_2(L5_2, L6_2)
    if L4_2 then
      L4_2 = math
      L4_2 = L4_2.min
      L5_2 = 120.0
      L6_2 = L3_1
      L6_2 = L6_2 + 0.5
      L4_2 = L4_2(L5_2, L6_2)
      L3_1 = L4_2
      L4_2 = SetCamFov
      L5_2 = L0_1
      L6_2 = L3_1
      L4_2(L5_2, L6_2)
    end
    L4_2 = IsControlJustPressed
    L5_2 = 0
    L6_2 = 47
    L4_2 = L4_2(L5_2, L6_2)
    if L4_2 then
      L4_2 = inGizmo
      if not L4_2 then
        L4_2 = GetCamRot
        L5_2 = L0_1
        L6_2 = 0
        L4_2 = L4_2(L5_2, L6_2)
        L5_2 = Round
        L6_2 = L0_2.x
        L7_2 = 2
        L5_2 = L5_2(L6_2, L7_2)
        L6_2 = Round
        L7_2 = L0_2.y
        L8_2 = 2
        L6_2 = L6_2(L7_2, L8_2)
        L7_2 = Round
        L8_2 = L0_2.z
        L9_2 = 2
        L7_2 = L7_2(L8_2, L9_2)
        L8_2 = Round
        L9_2 = L4_2.x
        L10_2 = 2
        L8_2 = L8_2(L9_2, L10_2)
        L9_2 = Round
        L10_2 = L4_2.z
        L11_2 = 2
        L9_2 = L9_2(L10_2, L11_2)
        L10_2 = L3_1
        L11_2 = lib
        L11_2 = L11_2.setClipboard
        L12_2 = "{ x = "
        L13_2 = L5_2
        L14_2 = ", y = "
        L15_2 = L6_2
        L16_2 = ", z = "
        L17_2 = L7_2
        L18_2 = ", rotX = "
        L19_2 = L8_2
        L20_2 = ", rotY = "
        L21_2 = L4_1
        L22_2 = ", rotZ = "
        L23_2 = L9_2
        L24_2 = ", fov = "
        L25_2 = L10_2
        L26_2 = " },"
        L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2 .. L24_2 .. L25_2 .. L26_2
        L11_2(L12_2)
        L11_2 = TriggerEvent
        L12_2 = "av_multicharacter:notification"
        L13_2 = "Editor"
        L14_2 = "Coords added to clipboard"
        L15_2 = "success"
        L11_2(L12_2, L13_2, L14_2, L15_2)
      end
    end
    L4_2 = IsControlPressed
    L5_2 = 0
    L6_2 = 20
    L4_2 = L4_2(L5_2, L6_2)
    if L4_2 then
      L4_2 = inGizmo
      if not L4_2 then
        L4_2 = SetNuiFocus
        L5_2 = true
        L6_2 = true
        L4_2(L5_2, L6_2)
        L4_2 = SendNUIMessage
        L5_2 = {}
        L5_2.action = "cam"
        L5_2.data = true
        L4_2(L5_2)
      end
    end
    L4_2 = Wait
    L5_2 = 1
    L4_2(L5_2)
  end
end
Loop = L5_1
function L5_1()
  local L0_2, L1_2
  L0_2 = L0_1
  return L0_2
end
GetCam = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = false
  L1_1 = L0_2
  L0_2 = DestroyCam
  L1_2 = L0_1
  L2_2 = false
  L0_2(L1_2, L2_2)
  L0_2 = RenderScriptCams
  L1_2 = false
  L2_2 = false
  L3_2 = 0
  L4_2 = true
  L5_2 = true
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
  L0_2 = nil
  L0_1 = L0_2
  L0_2 = DisplayHud
  L1_2 = true
  L0_2(L1_2)
  L0_2 = DisplayRadar
  L1_2 = true
  L0_2(L1_2)
  L0_2 = TriggerEvent
  L1_2 = "es:setMoneyDisplay"
  L2_2 = 1.0
  L0_2(L1_2, L2_2)
  L0_2 = FreezeEntityPosition
  L1_2 = cache
  L1_2 = L1_2.ped
  L2_2 = false
  L0_2(L1_2, L2_2)
end
DestroyFreeCam = L5_1
L5_1 = RegisterNUICallback
L6_1 = "enableCam"
function L7_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L5_1(L6_1, L7_1)
